package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity1 extends AppCompatActivity {
    ImageView btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0;
    ImageView btn_point, btn_equality, btn_qavs, btn_ac, btn_division, btn_percent, btn_multiplication, btn_munises, btn_plus, btn_plusmunises;
    TextView inputTxt, inputOutPut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        inputTxt = findViewById(R.id.inputTxt);
        inputOutPut = findViewById(R.id.inputOutPut);
        String data = null;

        btn_0 = findViewById(R.id.btn_0);
        btn_1 = findViewById(R.id.btn_1);
        btn_2 = findViewById(R.id.btn_2);
        btn_3 = findViewById(R.id.btn_3);
        btn_4 = findViewById(R.id.btn_4);
        btn_5 = findViewById(R.id.btn_5);
        btn_6 = findViewById(R.id.btn_6);
        btn_7 = findViewById(R.id.btn_7);
        btn_8 = findViewById(R.id.btn_8);
        btn_9 = findViewById(R.id.btn_9);
        btn_point = findViewById(R.id.btn_point);
        btn_equality = findViewById(R.id.btn_equality);
        btn_qavs = findViewById(R.id.btn_qavs);
        btn_ac = findViewById(R.id.btn_ac);
        btn_division = findViewById(R.id.btn_division);
        btn_percent = findViewById(R.id.btn_percent);
        btn_multiplication = findViewById(R.id.btn_multiplication);
        btn_munises = findViewById(R.id.btn_munises);
        btn_plus = findViewById(R.id.btn_plus);
        btn_plusmunises = findViewById(R.id.btn_plusmunises);

        btn_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "0");
            }
        });
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "1");
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "2");
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "3");
            }
        });
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "4");
            }
        });
        btn_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "5");
            }
        });
        btn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "6");
            }
        });
        btn_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "7");
            }
        });
        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "8");
            }
        });
        btn_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                inputTxt.setText(data + "9");
            }
        });
        btn_point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains(".") ||
                            data.contains(".")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + ".");
                    }
                }
            }
        });
        btn_ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputTxt.setText("");
                inputOutPut.setText("");
            }
        });

        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains("+") ||
                            data.substring(data.length() - 1, data.length()).contains("-") ||
                            data.substring(data.length() - 1, data.length()).contains("×") ||
                            data.substring(data.length() - 1, data.length()).contains("÷") ||
                            data.substring(data.length() - 1, data.length()).contains("%")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + "+");
                    }
                }
            }
        });
        btn_munises.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains("+") ||
                            data.substring(data.length() - 1, data.length()).contains("-") ||
                            data.substring(data.length() - 1, data.length()).contains("×") ||
                            data.substring(data.length() - 1, data.length()).contains("÷") ||
                            data.substring(data.length() - 1, data.length()).contains("%")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + "-");
                    }
                }
            }
        });
        btn_percent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains("+") ||
                            data.substring(data.length() - 1, data.length()).contains("-") ||
                            data.substring(data.length() - 1, data.length()).contains("×") ||
                            data.substring(data.length() - 1, data.length()).contains("÷") ||
                            data.substring(data.length() - 1, data.length()).contains("%")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + "%");
                    }
                }
            }
        });
        btn_multiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains("+") ||
                            data.substring(data.length() - 1, data.length()).contains("-") ||
                            data.substring(data.length() - 1, data.length()).contains("×") ||
                            data.substring(data.length() - 1, data.length()).contains("÷") ||
                            data.substring(data.length() - 1, data.length()).contains("%")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + "×");
                    }
                }
            }
        });
        btn_division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                if (data.length() != 0) {
                    if (data.substring(data.length() - 1, data.length()).contains("+") ||
                            data.substring(data.length() - 1, data.length()).contains("-") ||
                            data.substring(data.length() - 1, data.length()).contains("×") ||
                            data.substring(data.length() - 1, data.length()).contains("÷") ||
                            data.substring(data.length() - 1, data.length()).contains("%")) {
                        inputTxt.setText(data);
                    } else {
                        inputTxt.setText(data + "÷");
                    }
                }
            }
        });

        btn_equality.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = inputTxt.getText().toString();
                data = data.replaceAll("×", "*");
                data = data.replaceAll("%", "/100");
                data = data.replaceAll("÷", "/");

                Context rhino = Context.enter();
                rhino.setOptimizationLevel(-1);

                String finalResult = "";
                boolean isHave1 = data.endsWith("+");
                boolean isHave2 = data.endsWith("-");
                boolean isHave3 = data.endsWith("%");
                boolean isHave4 = data.endsWith("/");
                boolean isHave5 = data.endsWith("*");
                if (!(isHave1 || isHave2 || isHave3 || isHave4 || isHave5)) {
                    Scriptable scriptable = rhino.initStandardObjects();
                    finalResult = rhino.evaluateString(scriptable, data, "Javascript", 1, null).toString();
                    inputOutPut.setText(finalResult);
                }
            }
        });
    }
}